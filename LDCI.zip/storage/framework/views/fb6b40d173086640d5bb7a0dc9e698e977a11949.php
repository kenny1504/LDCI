<!-- ########## START: PANEL ########## -->
<div class="br-mainpanel">
 
  </div><!-- br-mainpanel -->
  <!-- ########## END: PANEL ########## --><?php /**PATH C:\laragon\www\LDCI\resources\views/theme/bracket/panel.blade.php ENDPATH**/ ?>