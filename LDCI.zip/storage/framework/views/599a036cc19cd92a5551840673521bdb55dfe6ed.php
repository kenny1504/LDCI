<div class="br-sideright">
    <!-- Tab panes -->
      <div class="tab-pane pos-absolute a-0 mg-t-60 overflow-y-auto" id="calendar" role="tabpanel">
        <label class="sidebar-label pd-x-25 mg-t-25">Fecha y Hora</label>
        <div class="pd-x-25">
          <h2 id="brTime" class="tx-white tx-lato mg-b-5"></h2>
          <h6 id="brDate" class="tx-white tx-light op-3"></h6>
        </div>

        <label class="sidebar-label pd-x-25 mg-t-25">Calendario</label>
        <div class="datepicker sidebar-datepicker"></div>
  
      </div>
  </div><?php /**PATH C:\laragon\www\LDCI\resources\views/theme/bracket/tabpanel.blade.php ENDPATH**/ ?>